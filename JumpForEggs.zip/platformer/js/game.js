var canvas=document.createElement('canvas');
var context=canvas.getContext('2d');
var high,levelCounter=0,eggsCounter=0;
var gameOver=false;
var levels=[
{
	background: "#dfd10f",
	level: `..........
..*.....*.
......//..
..**/.....
..........
../////...
.........*
/////...//
=======//=
==========`,
eggsCount: 5,
xPosition: 0,
yPosition: 0
},
{
	background: "mediumSeaGreen",
	level: `..........
..*.....*.
../...//..
..**/.....
..........
..///.....
...../....
........//
///====//=
==========`,
eggsCount: 4,
xPosition: 0,
yPosition: 0
},
{
	background: "#838383",
	level: `........*.
........//
......////
...*....*.
...//.*...
....////..
..........
///======/
=======///
==========`,
eggsCount: 4,
xPosition: 0,
yPosition: 0
}];
var mapScene=levels[levelCounter].level.trim().split('\n').map(l=>[...l]);
var water,fire,grass,spriteSheet,spriteSheet1;
var movement=8,player;
var xVel=yVel=0;
var spriteOffset=0;
var facingLeft=facingRight=false;
var jumpCount=0;
var bottom=false,onGround=false;
var holdingRight=holdingLeft=false;
var time=0;

//Player class
class Player{
	constructor(x,y){
		this.x=x;
		this.y=y;
		this.gravity=2;
		this.jump={
			jumping: false,
			jumpTimer: 1
		}
	}
}

  //////////////////////////
 ///Function Declaration///
//////////////////////////

window.onload=function(){
	canvas.width=640;
	canvas.height=640;
	document.body.appendChild(canvas);
	setInterval(update,1000/16);
	water=new Image();
	water.src="img/water.png";
	egg=new Image();
	egg.src="img/egg1.png";
	grass=new Image();
	grass.src="img/grass1.png";
	spriteSheet=new Image();
	spriteSheet.src="img/spriteSheetHen.png";
	spriteSheet1=new Image();
	spriteSheet1.src="img/spriteSheetHen1.png";
	//Defining a player
	player=new Player(levels[levelCounter].xPosition,levels[levelCounter].yPosition);
	facingRight=true;
}

function update(){
	let xPos,yPos;
	if(!gameOver){
	//Checking x coordinates
	if(holdingRight){
		xVel=movement;
	}
	else if(holdingLeft){
		xVel=-movement;
	}
	if(player.x+xVel<0 || player.x+xVel>640-64){
		xVel=0;
	}
	//Checking y coordinates
	if(player.y<0 && jumpCount!=8){
		yVel=-yVel;
		jumpCount=8;
	}
	if(player.y+yVel>canvas.height){
		yVel=0;
	}
	else{
	xPos=Math.round((player.x+xVel)/64);
	yPos=Math.round((player.y+yVel)/64);
	if(mapScene[yPos][xPos]=='.'){
		yVel=movement*player.gravity*2;
		onGround=false;
	}
	else if(mapScene[Math.round((player.y+yVel)/64)][xPos]=='*'){
		mapScene[yPos][xPos]='.';
		++eggsCounter;
		onGround=false;
	}
	else if(mapScene[yPos][xPos]=='='){
		yVel=0;
		onGround=false;
		console.log('=');
	}
	else if(mapScene[Math.round((player.y+yVel)/64)][xPos]=='/'){
		yVel=0;
		onGround=true;
		console.log('/');
	}
	// else{
	// 	player.y+=32;
	// 	onGround=true;
	// 	console.log('@');
	// }
	if(player.jump.jumping){
		// if(player.y+yVel>=64){
			
		// }
		yVel=-movement*player.gravity*2;
			var xPos1=Math.round((player.x+2*xVel)/64);
			var yPos1=Math.round((player.y+2*yVel)/64);
			if(player.y+yVel>=0){
				if(mapScene[yPos1][xPos1]=='/'){
				jumpCount=8;
				yVel=0;
			}
			}
			else{
				yVel=-yVel;
				jumpCount=8;
			}
	}
	if(jumpCount!=8 && player.jump.jumping){
		++jumpCount;
	}
	else if(jumpCount==8){
		player.jump.jumping=false;
		jumpCount=0;
	}
	}
	//finished the y co-ordinates
	player.y+=yVel;
	player.x+=xVel;

	//Completion of a level
	if(eggsCounter==levels[levelCounter].eggsCount){
		++levelCounter;
		eggsCounter=0;
		if(levelCounter<levels.length){
			mapScene=levels[levelCounter].level.trim().split('\n').map(l=>[...l]);
			player=new Player(levels[levelCounter].xPosition,levels[levelCounter].yPosition);
		}
	}
	//Drawing on the canvas
	if(levelCounter<levels.length){
		context.fillStyle=levels[levelCounter].background;
		context.fillRect(0,0,canvas.width,canvas.height);
		context.fillStyle='#5263a2';
		context.fillRect(0,canvas.width-(64*2),canvas.width,canvas.height);
	}
	else{
		gameOver=true;
	}
	//looping through the entire map
	for(let i=0;i<mapScene.length;i++){
		for(let j=0;j<mapScene[0].length;j++){
			if(mapScene[i][j]=='='){
				context.drawImage(water,j*64,i*64);
			}
			else if(mapScene[i][j]=='*'){
				high=Math.ceil(Math.random()*32);
				context.drawImage(egg,j*64+32,i*64+high);
			}
			else if(mapScene[i][j]=='/'){
				context.drawImage(grass,j*64,i*64);
			}
		}
	}

	//Drawing the player
	spriteOffset=(spriteOffset)%3;
	if(facingLeft){
		context.drawImage(spriteSheet1,spriteOffset*64,0,64,64,player.x,player.y,64,64);
	}
	else if(facingRight){
		context.drawImage(spriteSheet,spriteOffset*64,0,64,64,player.x,player.y,64,64);
	}
	++spriteOffset;
	}
	else{
		context.fillStyle="white";
		context.fillRect(0,0,canvas.width,canvas.height);
		context.fillStyle="black";
		context.font = "72pt sans-serif";
		context.fillText("You Win...", 64, canvas.height/2-72);
	}
}

document.addEventListener('keyup',(event)=>{
	switch(event.keyCode){
		case 37: 
		case 65: xVel=0;
			holdingLeft=false;
		break;
		case 68:
		case 39: xVel=0;
			holdingRight=false;
		break;
		case 32:
		break;
	}
	event.preventDefault();
});

window.addEventListener('keydown',(event)=>{
	if(event.keyCode==65 || event.keyCode==37){
		facingLeft=true;
		facingRight=false;
		holdingLeft=true;
		holdingRight=false;
	}
	if(event.keyCode==68 || event.keyCode==39){
		facingLeft=false;
		facingRight=true;
		holdingLeft=false;
		holdingRight=true;
	}
	if(event.keyCode==32){
		if(onGround && !player.jump.jumping){
		    player.jump.jumping=true;
		    onGround=false;
		}
	}
	event.preventDefault();
});